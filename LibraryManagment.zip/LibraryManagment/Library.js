"use strict";
var Genre;
(function (Genre) {
    Genre["Fiction"] = "Fiction";
    Genre["NonFiction"] = "NonFiction";
    Genre["Biography"] = "Biography";
    Genre["History"] = "History";
    Genre["Science"] = "Science";
})(Genre || (Genre = {}));
let BookTransaction;
function addBook(library, book) {
    library.push(book);
}
function searchByGenre(library, genre) {
    return library.filter((book) => book.genre == genre);
}
function checkoutBook(library, bookTitle) {
    let check = "";
    library.map((book) => {
        if (book.title == bookTitle) {
            if (book.isAvailable) { //console.log(book.title)
                book.isAvailable = false;
                check = "Book is available and successfully checked out.";
            }
            else {
                check = "Book is already checked out";
            }
        }
    });
    if (check == "")
        check = "Book is not found in the library";
    console.log(check);
    return check;
}
function returnBook(library, bookTitle) {
    let book = library.filter(book => book.title == bookTitle);
    console.log(book[0]);
    if (book[0]) {
        console.log("inside");
        if (book[0].isAvailable) {
            return "Book is not checked out";
        }
        else {
            book[0].isAvailable = true;
            return "Book is successfully returned";
        }
    }
    return "Book is not found in the library";
}
let library = [{ title: "Abc", author: "xyz", genre: Genre.Fiction, publishDate: "2023/09/09", isAvailable: true }, { title: "Ab", author: "xy", genre: Genre.History, publishDate: "2023/09/09", isAvailable: false }, { title: "Abcd", author: "wxyz", genre: Genre.NonFiction, publishDate: "2023/09/09", isAvailable: true }];
let AddBookToLibrary = () => {
    let titleId = document.getElementById("titleId");
    let author = document.getElementById("Author");
    let genre = document.getElementById("Genre");
    let bestseller = document.getElementById("Bestseller");
    let format = document.getElementsByName("Format");
    let publish = document.getElementById("Publish");
    let formatType = "";
    for (let i = 0; i < format.length; i++)
        if (format[i].checked) {
            formatType = format[i].value;
        }
    let book = { title: titleId.value, author: author.value, genre: genre.value, publishDate: publish.value, isAvailable: true, isBestseller: bestseller.value == "true" };
    book.format = formatType;
    try {
        if (book.title != "") {
            addBook(library, book);
            alert("Book Added successfully");
        }
        else
            alert("invalid");
    }
    catch (err) {
        console.log("err");
    }
};
function Search() {
    let genre = document.getElementById("selectGenre").value;
    let str = "";
    let arr = searchByGenre(library, genre);
    let divTable = document.getElementById("showTableDiv");
    divTable.style.display = "block";
    arr.map((book) => { str += `<tr><td>${book.title}</td><td>${book.author}</td><td>${book.genre}</td><td>${book.isAvailable}</td><td>${book.publishDate}</td>`; });
    let bodyTable = document.getElementById("showTableBody");
    bodyTable.innerHTML = str;
}
function checkOut() {
    checkoutBook(library, document.getElementById("bookLabel").value);
}
function handleReturnBook() {
    let book = document.getElementById("bookLabel1").value;
    console.log(book);
    alert(returnBook(library, book));
}
let fun = () => {
    document.getElementById("AddBook").addEventListener("click", AddBookToLibrary);
    document.getElementById("Search").addEventListener("click", Search);
    document.getElementById("checkout").addEventListener("click", checkOut);
    document.getElementById("returnBook").addEventListener("click", handleReturnBook);
    document.getElementById("OkButton").addEventListener("click", () => { document.getElementById("showTableDiv").style.display = "none"; });
};
onload = fun;
