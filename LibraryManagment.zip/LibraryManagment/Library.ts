interface Book {
    title: string;
    author: string
    genre: Genre;
    publishDate: string
    isAvailable: boolean;
    isBestseller?: boolean;
    format?: "Hardcover" | "Paperback" | "Ebook";
}
enum Genre {
    Fiction="Fiction", NonFiction="NonFiction", Biography="Biography", History="History", Science="Science"
}
type Library = Array<Book>;
let BookTransaction: [Book, string];
function addBook(library: Library, book: Book): void {
    library.push(book);
}
function searchByGenre(library: Library, genre: Genre): Book[] {
    return library.filter((book) => book.genre == genre);

}
function checkoutBook(library: Library, bookTitle: string): string {
    let check = "";
    
    library.map((book) => {
        if (book.title == bookTitle) {

            if (book.isAvailable) { //console.log(book.title)
                book.isAvailable = false;
                check = "Book is available and successfully checked out.";
            }
            else {
                check = "Book is already checked out";
            }
        }

    })
    if (check == "")
        check = "Book is not found in the library";
    console.log(check)
    return check;

}
function returnBook(library: Library, bookTitle: string): string {
      let book: Book[] = library.filter(book => book.title == bookTitle);
    console.log(book[0])
    if (book[0]) 
    { console.log("inside")
        if (book[0].isAvailable) {
           
            return "Book is not checked out"
        }
        else {
            book[0].isAvailable = true;
            return "Book is successfully returned"
        }
    }
    return "Book is not found in the library";
}
let library: Library = [{ title: "Abc", author: "xyz", genre: Genre.Fiction, publishDate: "2023/09/09", isAvailable: true }, { title: "Ab", author: "xy", genre: Genre.History, publishDate: "2023/09/09", isAvailable: false }, { title: "Abcd", author: "wxyz", genre: Genre.NonFiction, publishDate: "2023/09/09", isAvailable: true }]
let AddBookToLibrary=()=>{
    let titleId=document.getElementById("titleId") as HTMLInputElement
    let author=document.getElementById("Author") as HTMLInputElement
    let genre=document.getElementById("Genre") as HTMLInputElement
    let bestseller=document.getElementById("Bestseller") as HTMLInputElement
    let format=document.getElementsByName("Format") as NodeListOf<HTMLInputElement>
    let publish=document.getElementById("Publish") as HTMLInputElement
    let formatType="";
    for(let i =0;i<format.length;i++)
        if(format[i].checked)
        {  formatType=format[i].value as Genre;
        
        }

    let book:Book ={title:titleId.value,author:author.value,genre:genre.value as Genre,publishDate:publish.value,isAvailable:true,isBestseller:bestseller.value=="true"}
     book.format=formatType;
    try
     { if(book.title!="")
     {
        addBook(library,book)
        alert("Book Added successfully")
     }
     else
     alert("invalid")
    }
     catch(err)
     {
console.log("err")
     }

}
function Search()
{
    let genre=(document.getElementById("selectGenre") as HTMLSelectElement).value;
    let str="";
   let arr= searchByGenre(library,genre as Genre);
  let divTable= document.getElementById("showTableDiv") as HTMLDivElement
   divTable.style.display="block"
   
    arr.map((book)=>{str+=`<tr><td>${book.title}</td><td>${book.author}</td><td>${book.genre}</td><td>${book.isAvailable}</td><td>${book.publishDate}</td>`});
    let bodyTable=document.getElementById("showTableBody") as HTMLTableElement;
    bodyTable.innerHTML=str;
}
function checkOut()
{checkoutBook(library,(document.getElementById("bookLabel") as HTMLInputElement).value )

}
function handleReturnBook()
{  let book=(document.getElementById("bookLabel1") as HTMLInputElement).value;
    console.log(book)
   alert( returnBook(library,book))
}
let fun=()=>{
(document.getElementById("AddBook") as HTMLInputElement).addEventListener("click",AddBookToLibrary);
(document.getElementById("Search") as HTMLButtonElement).addEventListener("click",Search);
(document.getElementById("checkout") as HTMLButtonElement).addEventListener("click",checkOut);
(document.getElementById("returnBook") as HTMLButtonElement).addEventListener("click",handleReturnBook);
(document.getElementById("OkButton") as HTMLButtonElement).addEventListener("click",()=>{ (document.getElementById("showTableDiv") as HTMLDivElement).style.display="none"})
}
onload=fun;