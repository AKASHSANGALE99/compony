const $=(id)=>{return document.getElementById(id)}
function showDetails()
{ var gender="";
   var radioButton=document.getElementsByName("gender");
   for(let i=0;i<radioButton.length;i++)
   {
    if(radioButton[i].checked)
      gender=radioButton[i].value;
   }
 
  $("table").style.display='inline-block'
  $("AddressCol").innerText="Address:"+$("address").value;
$("nameCol").innerText=$("name").value;
$("genderCol").innerText=gender;
$("cityCol").innerText=$("city").value;

}