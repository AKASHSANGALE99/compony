var $ = (id) => {
    return document.getElementById(id);
}

var selectedId = 0;
axios.get('http://localhost:3000/users')
    .then(response => {
        showTable(response.data);
    })
    .catch(error => {
        console.error(error);
    });

function showTable(data) {
    let tableBody = document.querySelector('#tableId tbody');
    tableBody.innerHTML = "";
    data.forEach(user => {
        row = document.createElement('tr');
        row.innerHTML = `<td>${user.first_name}</td><td>${user.last_name}</td><td>${user.email}</td>`;
        row.onmouseover = () => { getUserDetails(user.id) };
        tableBody.appendChild(row);

    });
}
function getUserDetails(id) {
    selectedId = id;
    let http = new XMLHttpRequest();
    http.onload = () => {
        let Details = JSON.parse(http.responseText);

        const table = $("dataDisplay");
        const tbody = table.querySelector("tbody");
        tbody.innerText = "";
        for (const key in Details) {
            if (Details.hasOwnProperty(key)) {
                const row = tbody.insertRow();
                const cellKey = row.insertCell(0);
                const cellValue = row.insertCell(1);
                if (key != 'id') {
                    let vr = key.charAt(0).toUpperCase() + key.slice(1);

                    cellKey.innerHTML = `<b>${vr}</b>`;
                    cellValue.innerHTML = `<center> ${Details[key]}</center>`;
                }
            }
        }

        $("popup").style.visibility = "visible";
    }

    http.open("get", `http://localhost:3000/employees/${id}`, true);
    http.send();
}
function closePopup() {
    $("popup").style.visibility = "hidden";


}
function seeOnNextPage() {
    let http = new XMLHttpRequest();
    http.onload = () => {
        let Details = JSON.parse(http.responseText);
        Details = JSON.stringify(Details);

        sessionStorage.setItem('Details', Details);
    }
    http.open("get", `http://localhost:3000/employees/${selectedId}`, true);
    http.send();

}
function getDetails() {
    let Details = JSON.parse(sessionStorage.getItem("Details"));
    $("item1").innerHTML = `<b>FirstName:</b><br>${Details.first_name}`;
    $("item2").innerHTML = `<b>LastName:</b><br>${Details.last_name}`;
    $("item3").innerHTML = `<b>email:</b><br>${Details.email}`;
    $("item4").innerHTML = `<b>department:</b><br>${Details.department}`;
    $("item5").innerHTML = `<b>position:</b><br>${Details.position}`;
    $("item6").innerHTML = `<b>salary:</b><br>${Details.salary}`;

}
